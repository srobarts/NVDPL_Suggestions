
		<div class="row">
			<div class="span16 offset2">

				<p class="page_title" title="reports"></p>
				<h2>Reports</h2>


			</div> <!-- span -->
		</div> <!-- row -->